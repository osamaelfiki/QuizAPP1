package com.example.android.quizapp;

import android.app.Activity;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import static android.R.attr.name;
import static android.R.id.message;
import static android.icu.lang.UCharacter.GraphemeClusterBreak.V;
import static android.os.Build.VERSION_CODES.M;
import static com.example.android.quizapp.R.id.score;

public class MainActivity extends AppCompatActivity {
    int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    public void score(View V){
        calculateScore();

        EditText editText =(EditText) findViewById(R.id.name);
        String value = editText.getText().toString();
        String message = "hello "+value + " Thank you, and good luck. "+"\n your score ="+score+"of 5";
        ordermessage(message);
    }




    private void checkQuestionOne()
    {
        RadioGroup radioGroup =(RadioGroup) findViewById(R.id.groub);
        int radioButtonId = radioGroup.getCheckedRadioButtonId();

        if (radioButtonId == R.id.radio9)
            score=1;
    }

    private void checkQuestionTwo()
    {
        RadioGroup radioGroup =(RadioGroup) findViewById(R.id.groub2);
        int radioButtonId = radioGroup.getCheckedRadioButtonId();

        if (radioButtonId == R.id.radio4)
            score=++score;
    }
    private void checkQuestionThree ()
    {

        RadioGroup radioGroup =(RadioGroup) findViewById(R.id.groub3);
        int radioButtonId = radioGroup.getCheckedRadioButtonId();
        if (radioButtonId == R.id.radiod)
            score=++score;
    }


    private void checkQuestionFour()
    {
        EditText editText1 =(EditText) findViewById(R.id.edit2);

        if (editText1.getText().toString().equals("21"))
            score=++score;
    }
    private void calculateScore() {
        score = 0;
        checkQuestionOne();
        checkQuestionTwo();
        checkQuestionThree();
        checkQuestionFour();
        checkQuestionFive();
    }
    private void checkQuestionFive()
    {
        CheckBox firstAnswer =(CheckBox) findViewById(R.id.box1);
        CheckBox secondAnswer =(CheckBox) findViewById(R.id.box2);
        CheckBox thirdAnswer = (CheckBox)findViewById(R.id.box3);
        CheckBox fourthAnswer = (CheckBox)findViewById(R.id.box4);

        if (firstAnswer.isChecked() && secondAnswer.isChecked() && thirdAnswer.isChecked()
                && !fourthAnswer.isChecked())
            score=++score;
    }
    private void ordermessage (String message) {
        TextView messageText = (TextView) findViewById(R.id.score);
        messageText.setText("" + message);


    }
}
